
def sub_n(a,b):

    print(a-b)
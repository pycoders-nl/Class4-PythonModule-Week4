
def div_n(a,b):
    try:
        a/b
        return print(a / b)
    except ZeroDivisionError:
        print("the divisor cannot be zero!")


def sum_n(a,b):

    return print(a+b)
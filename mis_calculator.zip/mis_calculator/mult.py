
def mult_n(a,b):

    return print(a*b)
